/* Specify the instance specific configurations here.
Refer to the documentation on how to get these details for the Salesforce Commerce API */

var config = {};

config = {
  headers: {},
  parameters: {
    clientId: 'b19e12df-d55f-427a-bdba-6f49365ad4c8',
    organizationId: 'f_ecom_zzky_009',
    shortCode: 'kv7kzm78',
    siteId: 'RefArch'
  }
}

module.exports = config;